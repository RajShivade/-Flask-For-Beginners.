# Step 1 = Import Flask
from flask import Flask, request, render_template

# Step 2 = Initialise Flask Object
app = Flask(__name__)

# Step 3 = Create Your End Point/Route
@app.route("/")
def index():
    return render_template('home.html')

@app.route("/add")
def add_number():
    a = request.args.get("A")
    b = request.args.get("B")
    

    if a is None or b is None:
        return "Please Provide both A and b Query parameter"
    
    a = int(a)
    b = int(b)
    return str(a+b)

# Step 4 = Run the Application
if __name__ =='__main__':
    app.run(debug = True)