import addition_function

print(addition_function.add(1,2))