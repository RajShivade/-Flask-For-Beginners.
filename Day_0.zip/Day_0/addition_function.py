def add(a,b):
    return a+b

## Flask :
#1. Client Server appliction;
### Used In backend Develpoment as ## backend system architecture design.
## Client- server architecture and backend system architecture design. are almosat similar.

## Request resopnse server architecture