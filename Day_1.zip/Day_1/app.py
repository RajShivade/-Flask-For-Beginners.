# Step 1 = Import Flask
from flask import Flask


# Step 2 = Initialise Flask Object
app = Flask(__name__)


# Step 3 = Create Your End Point/Route
@app.route("/") 
def greet( ):
    return "Hello User"

@app.route("/add")
def add( ):
    a = 5
    b = 4
    return str(a+b)


# Step 4 = Run the Application
if __name__ =='__main__':
    app.run(debug = True)