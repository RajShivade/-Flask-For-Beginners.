# Step 1 = Import Flask
from flask import Flask

# Step 2 = Initialise Flask Object
app = Flask(__name__)

# Step 3 = Create Your End Point/Route
@app.route("/", methods = ['POST'])
def home_page():
    return "Welcome to Home Page"

@app.route("/about_us", methods = ['GET'])
def about_page( ):
    return "This is the About us page"

# Step 4 = Run the Application
if __name__ =='__main__':
    app.run(debug = True)